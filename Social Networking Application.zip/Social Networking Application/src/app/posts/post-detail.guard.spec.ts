/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/
import { TestBed, async, inject } from '@angular/core/testing';
import { PostDetailGuard } from './post-detail.guard';

/* Added for security */
describe('PostDetailGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PostDetailGuard]
    });
  });
  it('should ...', inject([PostDetailGuard], (guard: PostDetailGuard) => {
    expect(guard).toBeTruthy();
  }));
});
