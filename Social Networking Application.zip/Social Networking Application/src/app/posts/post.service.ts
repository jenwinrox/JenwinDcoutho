/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { IPost } from './post';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  private postUrl = 'api/posts/posts.json';

  constructor(private http: HttpClient) { }

  /** Get All Posts */
  getPosts(): Observable<IPost[]> {
    return this.http.get<IPost[]>(this.postUrl)
      .pipe(
      tap(),
      catchError(this.handleError)
      );
  }

  /** Get one Post */
  getPost(id: number): Observable<IPost | undefined> {
    return this.getPosts()
      .pipe(
      map((posts: IPost[]) => posts.find(p => p.id === id))
      );
  }

  private handleError(err: HttpErrorResponse) {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }

}
