/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { PostListComponent } from './post-list.component';
import { PostListDetailComponent } from './post-detail.component';
import { PostDetailGuard } from './post-detail.guard';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'posts', component: PostListComponent },
      {
        path: 'posts/:id',
        canActivate: [PostDetailGuard],
        component: PostListDetailComponent
      }
    ]),
    SharedModule
  ],
  declarations: [
    PostListComponent,
    PostListDetailComponent
  ]
})
export class PostModule { }
