/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/
import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { IPost } from './post';
import { PostService } from './post.service';
@Component({
  templateUrl: './post-list.component.html',
  styleUrls: ['./post-list.component.css']
})
export class PostListComponent implements OnInit {
  pageTitle = 'Post List';
  errorMessage = '';
  _listFilter = '';

  /* get & set filter */
  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredPosts = this.listFilter ? this.performFilter(this.listFilter) : this.posts;
  }

  filteredPosts: IPost[] = [];
  posts: IPost[] = [];

  /* Post service added to constructor */
  constructor(private postService: PostService,private router: Router) { }

  /* Filter/Search Actions */
  performFilter(filterBy: string): IPost[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.posts.filter((post: IPost) =>
      post.title.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  ngOnInit(): void {
    this.postService.getPosts().subscribe({
      next: posts => {
        this.posts = posts;
        this.filteredPosts = this.posts;
      },
      error: err => this.errorMessage = err
    });
  }

  /* Reading Local Storage */
  readLocalStorageValue(key) {
    return localStorage.getItem(key);
  }
  /* Logout */
  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
