/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/
/** Post Interface */
export interface IPost {
  userId: string;
  id: number;
  title: string;
  body: string;  
}
