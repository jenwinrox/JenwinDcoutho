/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IPost } from './post';
import { PostService } from './post.service';
@Component({
  templateUrl: './post-detail.component.html',
  styleUrls: ['./post-detail.component.css']
})
export class PostListDetailComponent implements OnInit {
  pageTitle = 'Post Detail';
  errorMessage = '';
  post: IPost | undefined;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private postService: PostService) {
  }

  ngOnInit() {
    const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = +param;
      this.getPost(id);
    }
  }

  /*Get one Post */
  getPost(id: number) {
    this.postService.getPost(id).subscribe({
      next: post => this.post = post,
      error: err => this.errorMessage = err
    });
  }

  onBack(): void {
    this.router.navigate(['/posts']);
  }
}
