/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/
import { Component, OnInit  } from '@angular/core';
import {  Router } from '@angular/router';

@Component({
  selector: 'pm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  pageTitle = 'Social Networking Application';

  ngOnInit() {
    const loggedIn = localStorage.getItem("isLoggedIn");
    if (loggedIn == "false") {
      this.router.navigate(['/login']);
    }
  }

  /* Reading Local Storage */
  readLocalStorageValue(key) {
    return localStorage.getItem(key);
  }

  /* Adding Constructor to Router */
  constructor(private router: Router) { }

  /* logout */
  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

}
