/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/

/** LoginUser Interface */
export interface LoginUser {
    username: string,
    password: string
}
