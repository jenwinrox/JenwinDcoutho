/* 
*  ===================
*  Author  @Jenwin 
*  Copyright (C) 2019
*/
import { Component, OnInit  } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginUser } from './login-user';
import { Observable } from 'rxjs';
import * as $ from 'jquery';

@Component({
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  public pageTitle = 'Login';
  constructor(private route: ActivatedRoute,
    private router: Router) {
  }
  /* Setting user as null initially  */
  originalLoginUser: LoginUser = {
    username: null,
    password: null
  };
  loginUser: LoginUser = { ...this.originalLoginUser };
  postError = false;
  postErrorMessage = '';
  subscriptionTypes: Observable<string[]>;

  ngOnInit() {
    localStorage.setItem('isLoggedIn', "false");
    localStorage.setItem('token', null);
  }

  onHttpError(errorResponse: any) {
    console.log('error: ', errorResponse);
    this.postError = true;
    this.postErrorMessage = errorResponse.error.errorMessage;
  }
  /*On Submit */
  onSubmit(form: NgForm) {
    if (form.valid) {
      localStorage.setItem('isLoggedIn', "true");
      localStorage.setItem('token', form.value.username);
      this.router.navigate(['/posts']);
    }
  }


}
